import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams } from "react-router-dom";

function Home() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("https://api.github.com/users")
      .then((res) => res.json())
      .then((data) => setUsers(data));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">GitHub Users</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {users.map((user) => (
          <div key={user.id} className="border rounded-xl p-4 shadow-md">
            <img src={user.avatar_url} alt={user.login} className="w-20 h-20 rounded-full" />
            <h2 className="text-lg font-semibold mt-2">{user.login}</h2>
            <p className="text-sm text-gray-500">ID: {user.id}</p>
            <Link to={`/user/${user.login}`} className="text-blue-600 mt-2 inline-block">View Profile</Link>
          </div>
        ))}
      </div>
    </div>
  );
}

function UserDetail() {
  const { username } = useParams();
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch(`https://api.github.com/users/${username}`)
      .then((res) => res.json())
      .then((data) => setUser(data));
  }, [username]);

  if (!user) return <div className="p-6">Loading...</div>;

  return (
    <div className="p-6">
      <Link to="/" className="text-blue-600">&larr; Back</Link>
      <div className="mt-4">
        <img src={user.avatar_url} alt={user.login} className="w-32 h-32 rounded-full" />
        <h1 className="text-2xl font-bold mt-2">{user.name || user.login}</h1>
        <p className="text-gray-600">{user.bio}</p>
        <ul className="mt-4 space-y-2">
          <li><strong>Username:</strong> {user.login}</li>
          <li><strong>Location:</strong> {user.location || "N/A"}</li>
          <li><strong>Company:</strong> {user.company || "N/A"}</li>
          <li><strong>Followers:</strong> {user.followers}</li>
          <li><strong>Following:</strong> {user.following}</li>
          <li><strong>Public Repos:</strong> {user.public_repos}</li>
          <li><a href={user.html_url} target="_blank" rel="noopener noreferrer" className="text-blue-600">GitHub Profile</a></li>
        </ul>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/user/:username" element={<UserDetail />} />
      </Routes>
    </Router>
  );
}